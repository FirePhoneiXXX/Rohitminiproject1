package com.dao;

import com.entity.Book;
import java.util.List;

public interface BookDaos {
    List<Book> getAllBooks();
    Book getBookById(long id);
    void addBook(Book book);
    void updateBook(Book book);
    void deleteBook(long id);
}
