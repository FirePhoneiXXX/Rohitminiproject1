package com.dao;

import com.entity.Book;

import java.util.ArrayList;
import java.util.List;

public class BookDao implements BookDaos {
    private List<Book> books;

    public BookDao() {
        this.books = new ArrayList<>();
        // Initialize with some sample data
        books.add(new Book(1, "The Great Gatsby", "F. Scott Fitzgerald", 15.99));
        books.add(new Book(2, "To Kill a Mockingbird", "Harper Lee", 12.50));
    }

    @Override
    public List<Book> getAllBooks() {
        return new ArrayList<>(books);
    }

    @Override
    public Book getBookById(long id) {
        for (Book book : books) {
            if (book.getId() == id) {
                return book;
            }
        }
        return null;
    }

    @Override
    public void addBook(Book book) {
        books.add(book);
    }

    @Override
    public void updateBook(Book book) {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getId() == book.getId()) {
                books.set(i, book);
                return;
            }
        }
    }

    @Override
    public void deleteBook(long id) {
        books.removeIf(book -> book.getId() == id);
    }
}