package com.controller;

import com.dao.BookDaos;
import com.dao.BookDao;
import com.service.BookService;
import com.service.BookServiceImpl;

public class BookstoreApplication {
    public static void main(String[] args) {
        // Initialize DAO, Service, and Controller
        BookDaos bookDao = new BookDao();
        BookService bookService = new BookServiceImpl(bookDao);
        BookController bookController = new BookController(bookService);

        // Run the application
        bookController.run();
    }
}