package com.controller;

import com.entity.Book;
import com.service.BookService;

import java.util.List;
import java.util.Scanner;

public class BookController {
    private BookService bookService;
    private Scanner scanner;

    public BookController(BookService bookService) {
        this.bookService = bookService;
        this.scanner = new Scanner(System.in);
    }

    public void run() {
        int choice;
        do {
            System.out.println("1. View all books");
            System.out.println("2. View book by ID");
            System.out.println("3. Add a book");
            System.out.println("4. Update a book");
            System.out.println("5. Delete a book");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    viewAllBooks();
                    break;
                case 2:
                    viewBookById();
                    break;
                case 3:
                    addBook();
                    break;
                case 4:
                    updateBook();
                    break;
                case 5:
                    deleteBook();
                    break;
                case 0:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        } while (choice != 0);
    }

    private void viewAllBooks() {
        List<Book> books = bookService.getAllBooks();
        if (books.isEmpty()) {
            System.out.println("No books available.");
        } else {
            for (Book book : books) {
                System.out.println(book);
            }
        }
    }

    private void viewBookById() {
        System.out.print("Enter book ID: ");
        long id = scanner.nextLong();
        scanner.nextLine(); // Consume the newline character
        Book book = bookService.getBookById(id);
        if (book != null) {
            System.out.println(book);
        } else {
            System.out.println("Book not found.");
        }
    }

    private void addBook() {
        scanner.nextLine(); // Consume the newline character
        System.out.print("Enter book title: ");
        String title = scanner.nextLine();
        System.out.print("Enter book author: ");
        String author = scanner.nextLine();
        System.out.print("Enter book price: ");
        double price = scanner.nextDouble();

        Book newBook = new Book();
        newBook.setTitle(title);
        newBook.setAuthor(author);
        newBook.setPrice(price);

        bookService.addBook(newBook);
        System.out.println("Book added successfully.");
    }

    private void updateBook() {
        System.out.print("Enter book ID to update: ");
        long id = scanner.nextLong();
        scanner.nextLine(); // Consume the newline character
        Book existingBook = bookService.getBookById(id);

        if (existingBook != null) {
            System.out.print("Enter new book title: ");
            String newTitle = scanner.nextLine();
            System.out.print("Enter new book author: ");
            String newAuthor = scanner.nextLine();
            System.out.print("Enter new book price: ");
            double newPrice = scanner.nextDouble();

            existingBook.setTitle(newTitle);
            existingBook.setAuthor(newAuthor);
            existingBook.setPrice(newPrice);

            bookService.updateBook(existingBook);
            System.out.println("Book updated successfully.");
        } else {
            System.out.println("Book not found.");
        }
    }

    private void deleteBook() {
        System.out.print("Enter book ID to delete: ");
        long id = scanner.nextLong();
        scanner.nextLine(); // Consume the newline character
        bookService.deleteBook(id);
        System.out.println("Book deleted successfully.");
    }
}
