package com.service;

import com.dao.BookDao;
import com.dao.BookDaos;
import com.entity.Book;

import java.util.List;

public class BookServiceImpl implements BookService {
    private BookDaos bookDao;

    public BookServiceImpl(BookDaos bookDao2) {
        this.bookDao = bookDao2;
    }

    @Override
    public List<Book> getAllBooks() {
        return bookDao.getAllBooks();
    }

    @Override
    public Book getBookById(long id) {
        return bookDao.getBookById(id);
    }

    @Override
    public void addBook(Book book) {
        bookDao.addBook(book);
    }

    @Override
    public void updateBook(Book book) {
        bookDao.updateBook(book);
    }

    @Override
    public void deleteBook(long id) {
        bookDao.deleteBook(id);
    }
}